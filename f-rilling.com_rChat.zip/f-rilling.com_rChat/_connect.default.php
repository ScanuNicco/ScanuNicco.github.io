<?php

$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="chatapp";

?>